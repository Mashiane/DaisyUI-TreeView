// filepath: c:\Users\User\Downloads\DaisyUITreeView\jest.setup.js
import { TextEncoder, TextDecoder } from 'util';

global.TextEncoder = TextEncoder;
global.TextDecoder = TextDecoder;